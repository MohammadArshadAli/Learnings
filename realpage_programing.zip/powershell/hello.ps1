$var="world"
write-host "hello" $var