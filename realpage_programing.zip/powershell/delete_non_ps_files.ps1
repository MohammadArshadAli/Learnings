$classFiles = Get-ChildItem | where-Object {! ($_.Extension.Equals(".ps1"))}
$classFiles | ForEach-Object{Write-Output ""}{Write-Output $_.Name}{Write-Output "" "Delete all the above files?"}

$confirmation = Read-Host -Prompt "Is this correct (y/n)?"

if ($confirmation.ToLower().Equals("y")) {
    # $classFiles | ForEach-Object {$_.Delete()}
    Write-Output "Deleted.."
}