import java.util.*;

public class binaryComplement {
    public static void main(String[] args) {
        System.out.println(new Solution().findComplement(new Scanner(System.in).nextInt()));
    }
}


class Solution {
    public int findComplement(int num) {
        int numBits= (int) (Math.log(num)/Math.log(2) +1); //to count number of bits required for the number

        // int numBits = Integer.toBinaryString(num).length();

        int allOnes;
        // allOnes=1
        // for(int i=0; i<numBits-1; i++){
        //    allOnes<<=1;
        //    allOnes|=1;
        // }
        //alternatively do the below
        allOnes=(1<<numBits) -1;

        // return (~num)&allOnes;
        return num^allOnes;

    }
}


//0  101
//111 010  

//1010

//  101
//  010
//  010
