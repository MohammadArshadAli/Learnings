//leetcode: https://leetcode.com/problems/flood-fill

public class floodFill {
    public static void main(String[] args) {
        
    }
}

class Solution {
    public int[][] floodFill(int[][] image, int sr, int sc, int color) {
        int[][] directions = new int[][]{{-1,0}, {0,1}, {1,0}, {0,-1}};
        dfs(sr,sc,image,color,directions);

        return image;
    }

    static void dfs(int x,int y, int[][] image,int COLOR,int[][] DIRECTIONS){
        
        int currColor=image[x][y];
        if(currColor==COLOR)
            return;
        image[x][y]=COLOR;

        for(int[] dir: DIRECTIONS){
            int newX=x+dir[0];
            int newY=y+dir[1];

            if(newX >=0 && newX<image.length && newY>=0 && newY<image[0].length && image[newX][newY]==currColor){
                dfs(newX,newY, image, COLOR, DIRECTIONS);
            }
        }

    }
}
