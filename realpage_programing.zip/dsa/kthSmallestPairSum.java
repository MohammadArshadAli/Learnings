import java.util.*;

/**
 * kthSmallestPairSum 
 */

 //! the binar search sum doesn't exist in the array
public class kthSmallestPairSum {

    static class Solution {
        public static int smallestDistancePair(int[] nums, int k) {
            Arrays.sort(nums);
            
            int end=absDiff(nums[0], nums[nums.length-1]);
            int st=0, mid;

            //binary search

            while(st<=end){ //!
                mid= (end-st)/2 +st;
                System.out.print(" "+mid);

                int numLessPairs= countLesserPairs(mid,nums,k);

                if (numLessPairs<(k-1))
                    st=mid+1;
                else
                    end=mid-1;
                
            }

            return st;
            
        }

        static int absDiff(int a, int b){
            return Math.abs(a-b);
        }
        
        static int countLesserPairs(int target, int[] nums, int k){
            int st=0,end=1,count=0;

            for(; st<nums.length-1; st++){
                while(end<nums.length && absDiff(nums[st], nums[end])<target){ //! <target
                    count++;
                    end++;
                }
            }
            return count;
        }
    }

    public static void main(String[] args) {
        System.out.println(Solution.smallestDistancePair(new int[]{1,1,1}, 2));
    }
}