import java.util.HashSet;
import java.util.Set;

public class rough {
    public static void main(String[] args) {
        Set<Set<Integer>> sett= new HashSet<>();
        Set<Integer> s= new HashSet<>();
        s.add(3);
        s.add(4);
        sett.add(s);
        
        s= new HashSet<>();
        s.add(3);
        s.add(4);
        System.out.println((sett.contains(s)));

    }
}
