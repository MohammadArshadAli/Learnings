import java.util.*;

class strangePrinter{
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);

        String s= sc.next();
        System.out.println(new Solution().strangePrinter(s));
        sc.close();
    }
}

class Solution {
    public int strangePrinter(String s) {
        
    }
}



