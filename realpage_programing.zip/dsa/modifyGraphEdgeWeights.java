//leetcode: https://leetcode.com/problems/modify-graph-edge-weights/description

import java.util.*;

public class modifyGraphEdgeWeights {

}



class Solution {
    public int[][] modifiedGraphEdges(int n, int[][] edges, int source, int destination, int target) {
        // find shotest path.. by assigning all -1 as 1..
        // if teh shortest path <= target then ok else return []
        // then assign the weights to the edges any way
        int dist[] = new int[n];
        int parent[] = new int[n];
        for (int i = 0; i < n; dist[i] = Integer.MAX_VALUE,parent[i++] = -1)
            ;
        dist[source] = 0;

        bellmanFord(dist, parent,n, edges, source);

        System.out.println(Arrays.toString(parent));
        System.out.println(Arrays.toString(dist));

        if(dist[destination]==Integer.MAX_VALUE || dist[destination]>target)
            return new int[0][0];

        //making adj
        int[][] adj = new int[n][n];
        // for(int i=0; i<n; i++, adj.add(new ArrayList<>()));

        for(int edge[]: edges){
            int from = edge[0];
            int to = edge[1];
            int w = edge[2];

            adj[from][to]=w;
            adj[to][from]=w;
        }

        //assigning weights..


        int curr=destination, curr_dist=0;
        Set<String> from_to_minus1= new HashSet<>();

        while(curr!=source){
            
            int w=adj[curr][parent[curr]];
            if(w==-1){
                from_to_minus1.add(String.format("%d-%d",parent[curr], curr));
            }
            else
                curr_dist+=w;
            curr=parent[curr];
        }


        System.out.println(from_to_minus1);
        //checking, and assigning weights
        int weightRemaining=target-curr_dist;
        double div= from_to_minus1.size()>0? ((double)weightRemaining/from_to_minus1.size()) : (1e8);//1e8>1e7

        if(div>1e7)
            return new int[0][0]; // max limit for a node is 10^7.

        //assigning
        int edge[]=null,last_minus_ind=-1;


        for( int i=0; i<edges.length; i++){
            edge= edges[i];
            int from = edge[0];
            int to = edge[1];
            int w = edge[2];

            if(from_to_minus1.contains(String.format("%d-%d",from, to)) || from_to_minus1.contains(String.format("%d-%d",to, from))){
                edges[i][2]=(int)div;
                last_minus_ind=i;

            }
            else if(w==-1) //changind rest of -1s which do not come in the path
                edges[i][2]=1;
        }
        edges[last_minus_ind][2]+= weightRemaining%from_to_minus1.size();// to add the remaining dist from the dividion div.. //might cause overflow    
        // System.out.println(Arrays.deepToString(edges));

        return edges;

    }

    void bellmanFord(int dist[], int parent[], int n, int[][] edges, int source) {

        for (int k = 0; k < n - 1; k++) {
            boolean updated = false;

            for (int[] edge : edges) {
                int from = edge[0];
                int to = edge[1];
                int w = edge[2];
                w = (w == -1) ? 1 : w; //assigning all -1 as 1

                if(dist[from]!=Integer.MAX_VALUE && ((dist[from]+w)<dist[to])){ //! if there is more than one shortest dist (i.e equal), then we should choose the one with most -1s.
                    updated=true;

                    dist[to] = (dist[from]+w);
                    parent[to]=from;
                }
                
                if(dist[to]!=Integer.MAX_VALUE && ((dist[to]+w)<dist[from])){ //! if there is more than one shortest dist (i.e equal), then we should choose the one with most -1s.
                    updated=true;

                    dist[from] = (dist[to]+w);
                    parent[from]=to;
                }

            }

            if(!updated)
                return;
        }

    }

}