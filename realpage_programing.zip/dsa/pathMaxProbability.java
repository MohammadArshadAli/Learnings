import java.util.*;

public class pathMaxProbability {
    public static void main(String[] args) {
        
    }
}

class Solution {
    public double maxProbability(int n, int[][] edges, double[] succProb, int start_node, int end_node) {
        double prob[]= new double[n];

        prob[start_node]=1;

        for(int i=0; i<n-1; i++){
            boolean updated=false;
            for(int j=0; j<edges.length; j++){
                int n1=edges[j][0];
                int n2=edges[j][1];

                if((prob[n1]!=0) && ((prob[n1] * succProb[j])>prob[n2])){
                    prob[n2]=(prob[n1] * succProb[j]);
                    updated=true;
                }

                if((prob[n2]!=0) && ((prob[n2] * succProb[j])>prob[n1])){
                    prob[n1]=(prob[n2] * succProb[j]);
                    updated=true;
                }

            }
            if(!updated)
                break;
        }

        // System.out.println(Arrays.deepToString(adj));



        return prob[end_node]; //!equals might not work correctly

    }

}
