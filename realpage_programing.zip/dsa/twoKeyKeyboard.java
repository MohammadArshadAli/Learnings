//leetcode: https://leetcode.com/problems/2-keys-keyboard


import java.util.*;
class twoKeyKeyboard {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n=sc.nextInt();
        // System.out.println(new SolutionRecursion().minSteps(n));
        System.out.println(new SolutionFactorization().minSteps(n));
        sc.close();

    }
}
class SolutionRecursion {
    public int minSteps(int n) {
        if (n==1)
            return 0;
        return 2 + helper(2,1,n);
    }

    static int helper(int currCount, int copied, int n){
        if(currCount>n)
            return -1;
        if(currCount==n)
            return 0;

        int resCurr=helper(currCount+copied,copied,n);
        int resCopy=helper(currCount+currCount,currCount,n);

        if(resCurr==-1)
            return -1;
        
        if(resCopy==-1)
            return resCurr+1;
        
        return Math.min(resCurr+1,resCopy+2);
    }
}

class SolutionFactorization {
    public int minSteps(int n) {
        if (n == 1) return 0;
        
        int steps = 0;
        int factor = 2;
        
        while (n > 1) {
            while (n % factor == 0) {
                // System.out.println(factor);
                steps += factor;
                n /= factor;
            }
            factor++;
        }
        
        return steps;
    }
}