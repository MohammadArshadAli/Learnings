import java.math.BigInteger;
import java.util.*;


public class fractionArithmetic {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s= sc.next();

        System.out.println(new Solution().fractionAddition(s));

        sc.close();
    }    
}

