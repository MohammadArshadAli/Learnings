var="world"
echo "hello $var"