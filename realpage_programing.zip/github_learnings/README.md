# Learnings
### 1. Linux theory and bash commands
### 2. Git and Github
### 3. Powershell 